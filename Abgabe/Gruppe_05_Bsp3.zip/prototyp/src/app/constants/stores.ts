export const STORE_ROUTER = 'router';
export const STORE_ENTRIES = 'entries';
